
/**
 *
 * @author Giovani
 */
public class EkstaziDTest {

    @org.junit.Test
    public void testD1() {
        EkstaziD d = new EkstaziD();
        d.methodFromEkstaziD();
    }

}
