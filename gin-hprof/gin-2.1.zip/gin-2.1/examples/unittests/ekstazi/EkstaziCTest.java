
/**
 *
 * @author Giovani
 */
public class EkstaziCTest {

    @org.junit.Test
    public void testC1() {
        EkstaziC c = new EkstaziC();
        c.methodFromEkstaziC();
    }

}
