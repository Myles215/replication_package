package mypackage;

public class ExampleBase {

    int justAField = 100;

    public ExampleBase() {

    }

}
