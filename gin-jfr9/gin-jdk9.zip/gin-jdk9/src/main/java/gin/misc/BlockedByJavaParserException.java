package gin.misc;



public class BlockedByJavaParserException extends Exception {

   
    private static final long serialVersionUID = -6294766516508009325L;

    public BlockedByJavaParserException(String message) {
        super(message);
    }

}
