package gin.edit.modifynode;



public class NoApplicableNodesException extends Exception {

   
    private static final long serialVersionUID = 8641428365818887525L;

}
