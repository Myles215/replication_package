package gin.category;

public interface LocalTest {
}
