
/**
 *
 * @author Giovani
 */
public class EkstaziE {
    
    public void methodFromEkstaziE(){
        System.out.println("EkstaziE.methodFromEkstaziE()");
    }

}
