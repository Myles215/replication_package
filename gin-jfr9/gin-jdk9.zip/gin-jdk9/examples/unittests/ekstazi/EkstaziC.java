
/**
 *
 * @author Giovani
 */
public class EkstaziC {
    
    public void methodFromEkstaziC(){
        System.out.println("EkstaziC.methodFromEkstaziC()");
    }

}
