package gin;
public class Small {
    public static void Dummy() {
        int a = 1;
        int b = 2;
        int c = a + b;
        if ((a < b) || (a > c)) {
                c++;
        }
    }
}
