Useless file so we can add otherwise empty directory to git
