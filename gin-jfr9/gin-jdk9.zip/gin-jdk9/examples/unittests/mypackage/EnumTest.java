package mypackage;

public enum EnumTest {
	A,B,C;
	
	public void doStuff() {
		
	}
	
	public static class InnerClass {
		public void moreStuff() {
			
		}
	}
}
