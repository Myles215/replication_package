package mypackage;

public class Simple {

    public boolean returnsTrue() {
        boolean flag = false;
        flag = true;
        return flag;
    }

}