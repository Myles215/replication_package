#!/usr/bin/env bash

ln -s ./pre-commit.sh ../.git/hooks

