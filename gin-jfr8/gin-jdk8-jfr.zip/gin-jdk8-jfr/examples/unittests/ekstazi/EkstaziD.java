
/**
 *
 * @author Giovani
 */
public class EkstaziD {
    
    public void methodFromEkstaziD(){
        System.out.println("EkstaziD.methodFromEkstaziD()");
    }

}
