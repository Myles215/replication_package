
/**
 *
 * @author Giovani
 */
public class EkstaziA {

    public int methodA() {
        EkstaziB b = new EkstaziB();
        return b.sum(2, 2);
    }

    public int methodB() {
        return 0;
    }

}
