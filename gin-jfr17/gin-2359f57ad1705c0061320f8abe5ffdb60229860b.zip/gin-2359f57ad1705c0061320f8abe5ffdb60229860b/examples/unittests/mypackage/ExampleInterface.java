package mypackage;

interface ExampleInterface {

    public String hello = "SimpleString";

    public void exampleMethod();


}