This benchmark was originally in Gin release 1.0 (in the "examples/locoGP" folder). It has now been packaged as a Maven
project for ease of use.
