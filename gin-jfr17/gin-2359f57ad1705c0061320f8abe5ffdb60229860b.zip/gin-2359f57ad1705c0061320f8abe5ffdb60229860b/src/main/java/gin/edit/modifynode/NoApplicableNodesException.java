package gin.edit.modifynode;

import java.io.Serial;

public class NoApplicableNodesException extends Exception {

    @Serial
    private static final long serialVersionUID = 8641428365818887525L;

}
